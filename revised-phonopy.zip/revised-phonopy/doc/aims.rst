.. _FHI_aims_interface:

FHI-aims & phonopy calculations
===============================

See `example/diamond-FHI-aims` in the `phonopy` source.
